const inventorSelect = document.getElementById("inventorSelect");
const inventorImg = document.getElementById("inventorImg");
const inventorInfo = document.getElementById("inventorInfo");

const inventors = {
    ritchie: {
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/23/Dennis_Ritchie_2011.jpg/440px-Dennis_Ritchie_2011.jpg",
        info: "Dennis Ritchie created the C programming language at Bell Labs."
    },
    gosling: {
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/James_Gosling_2008.jpg/500px-James_Gosling_2008.jpg",
        info: "James Gosling is the inventor of Java."
    },
    guido: {
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/Guido_van_Rossum_OSCON_2006.jpg/440px-Guido_van_Rossum_OSCON_2006.jpg",
        info: "Guido van Rossum is the creator of Python."
    },
    stroustrup: {
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Bjarne_Stroustrup_%282013%29.jpg/500px-Bjarne_Stroustrup_%282013%29.jpg",
        info: "Bjarne Stroustrup developed C++."
    },
    eich: {
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Brendan_Eich_Mozilla_Foundation_official_photo.jpg/500px-Brendan_Eich_Mozilla_Foundation_official_photo.jpg",
        info: "Brendan Eich invented JavaScript."
    },
    rasmus: {
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/Rasmus_Lerdorf_August_2014_%28cropped%29.JPG/500px-Rasmus_Lerdorf_August_2014_%28cropped%29.JPG",
        info: "Rasmus Lerdorf created PHP."
    },
    matsumoto: {
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Yukihiro_Matsumoto_%282018%29.jpg/500px-Yukihiro_Matsumoto_%282018%29.jpg",
        info: "Yukihiro Matsumoto is the creator of Ruby."
    },
    hejsberg: {
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Anders_Hejlsberg.jpg/500px-Anders_Hejlsberg.jpg"
        info: "Anders Hejlsberg developed C#."
    },
    hopper: {
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/Grace_Hopper.jpg/440px-Grace_Hopper.jpg",
        info: "Grace Hopper developed COBOL."
    },
    mccarthy: {
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/John_McCarthy_Stanford.jpg/440px-John_McCarthy_Stanford.jpg",
        info: "John McCarthy invented Lisp."
    }
};

inventorSelect.addEventListener("change", () => {
    const key = inventorSelect.value;

    if (key && inventors[key]) {
        inventorImg.src = inventors[key].img;
        inventorInfo.textContent = inventors[key].info;
    } else {
        inventorImg.src = "";
        inventorInfo.textContent = "Select an inventor to see details.";
    }
});